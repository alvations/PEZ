Firstly, pardon the change in our team name due to my transfer from one university to another. Previously, our name was *XLING*, it has been changed to *Sensible*. 

We ran three system configuration for all language pairs, the filenames are named with the following convention:
  
  team_name.system_name.config.src-trg.best/oof

This .zip file contains the following files:
- README
- team-description.txt
- Config 1 runs:
		sensible.pez.wtm.de-en.best
		sensible.pez.wtm.de-en.oof
		sensible.pez.wtm.en-fr.best
		sensible.pez.wtm.en-fr.oof
		sensible.pez.wtm.en-nl.best
		sensible.pez.wtm.en-nl.oof
		sensible.pez.wtm.es-en.best
		sensible.pez.wtm.es-en.oof
- Config 2 runs:
		sensible.pez.wtmxling.de-en.best
		sensible.pez.wtmxling.de-en.oof
		sensible.pez.wtmxling.en-fr.best
		sensible.pez.wtmxling.en-fr.oof
		sensible.pez.wtmxling.en-nl.best
		sensible.pez.wtmxling.en-nl.oof
		sensible.pez.wtmxling.es-en.best
		sensible.pez.wtmxling.es-en.oof
- Config 3 runs:
		sensible.pez.wtmxlingyu.de-en.best
		sensible.pez.wtmxlingyu.de-en.oof
		sensible.pez.wtmxlingyu.en-fr.best
		sensible.pez.wtmxlingyu.en-fr.oof
		sensible.pez.wtmxlingyu.en-nl.best
		sensible.pez.wtmxlingyu.en-nl.oof
		sensible.pez.wtmxlingyu.es-en.best
		sensible.pez.wtmxlingyu.es-en.oof

